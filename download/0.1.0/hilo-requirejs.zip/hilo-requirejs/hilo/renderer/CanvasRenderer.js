/**
 * Hilo 0.1.0 for RequireJS
 * Copyright 2014 hilojs.com
 * Licensed under the MIT License
 */

define('hilo/renderer/CanvasRenderer', ['hilo/core/Class', 'hilo/renderer/Renderer'], function(Class, Renderer){

/**
 * @class canvas画布渲染器。所有可视对象将渲染在canvas画布上。
 * @augments Renderer
 * @param {Object} properties 创建对象的属性参数。可包含此类所有可写属性。
 * @module hilo/renderer/CanvasRenderer
 * @requires hilo/core/Class
 * @requires hilo/renderer/Renderer
 * @property {CanvasRenderingContext2D} context canvas画布的上下文。
 */
var CanvasRenderer = Class.create(/** @lends CanvasRenderer.prototype */{
    Extends: Renderer,
    constructor: function CanvasRenderer(properties){
        CanvasRenderer.superclass.constructor.call(this, properties);
        
        var canvas = this.canvas,
            width = properties.width,
            height = properties.height;
            
        this.context = canvas.getContext("2d");
        if(width && height){
            canvas.width = width;
            canvas.height = height;
        }
    },

    context: null,

    /**
     * @private
     * @see Renderer#startDraw
     */
    startDraw: function(target){
        if(target instanceof Stage){
            this.context.clearRect(0, 0, target.width, target.height);
        }
        this.context.save();
    },

    /**
     * @private
     * @see Renderer#draw
     */
    draw: function(target){
        var drawable = target.drawable;
        if(!drawable || !drawable.image) return;
        var ctx = this.context, rect = drawable.rect;
        ctx.drawImage(drawable.image, rect[0], rect[1], rect[2], rect[3], 0, 0, target.width, target.height);
    },

    /**
     * @private
     * @see Renderer#endDraw
     */
    endDraw: function(target){
        this.context.restore();
    },

    /**
     * @private
     * @see Renderer#transform
     */
    transform: function(target){
        var ctx = this.context,
            scaleX = target.scaleX,
            scaleY = target.scaleY;
        
        if(target instanceof Stage){
            var style = this.canvas.style,
                oldScaleX = target._scaleX,
                oldScaleY = target._scaleY;

            if((!oldScaleX && scaleX != 1) || (oldScaleX && oldScaleX != scaleX)){
                target._scaleX = scaleX;
                style.width = scaleX * target.width + "px";
            }
            if((!oldScaleY && scaleY != 1) || (oldScaleY && oldScaleY != scaleY)){
                target._scaleY = scaleY;
                style.height = scaleY * target.height + "px";
            }
        }else{
            var x = target.x,
                y = target.y,
                pivotX = target.pivotX,
                pivotY = target.pivotY,
                rotation = target.rotation % 360;

            if(x != 0 || y != 0) ctx.translate(x, y);
            if(rotation != 0) ctx.rotate(rotation * Math.PI / 180);
            if(scaleX != 1 || scaleY != 1) ctx.scale(scaleX, scaleY);
            if(pivotX != 0 || pivotY != 0) ctx.translate(-pivotX, -pivotY);
        }
        
        if(target.alpha > 0) ctx.globalAlpha *= target.alpha;
    },

    /**
     * @private
     * @see Renderer#remove
     */
    remove: function(target){
        if(target instanceof DOMElement){
            var elem = target.drawable.domElement,
                parentElem = elem && elem.parentNode;
            if(parentElem){
                parentElem.removeChild(elem);
            }
        }
    },

    /**
     * @private
     * @see Renderer#clear
     */
    clear: function(x, y, width, height){
        this.context.clearRect(x, y, width, height);
    }
});

return CanvasRenderer;

});