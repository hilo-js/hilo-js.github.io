/**
 * Hilo 0.1.0 for KISSY
 * Copyright 2014 hilojs.com
 * Licensed under the MIT License
 */

KISSY.add('hilo/view/Stage', function(S, Hilo, Class, Container){

/**
 * @class 舞台是可视对象树的根，可视对象只有添加到舞台或其子对象后才会被渲染出来。
 * @augments Container
 * @param {Object} properties 创建对象的属性参数。可包含此类所有可写属性。
 * @module hilo/view/Stage
 * @requires hilo/core/Hilo
 * @requires hilo/core/Class
 * @requires hilo/view/Container
 * @property {HTMLElement} canvas 舞台所对应的画布。它可以是一个canvas或一个普通的div。只读属性。可通过构造函数传入。
 * @property {Renderer} renderer 舞台渲染器。只读属性。
 * @property {Boolean} paused 指示舞台是否暂停刷新渲染。 
 * @property {Object} viewport 舞台内容在页面中的渲染区域。包含的属性有：left、top、width、height。只读属性。
 */
var Stage = Class.create(/** @lends Stage.prototype */{
    Extends: Container,
    constructor: function Stage(properties){
        properties = properties || {};
        this.id = this.id || properties.id || Hilo.getUid("Stage");
        Stage.superclass.constructor.call(this, properties);
        
        var canvas = this.canvas;
        if(canvas){
            if(canvas.getContext){
                this.renderer = new CanvasRenderer(properties);
            }else{
                this.renderer = new DOMRenderer(properties);
            }
        }else{
            throw new Error("Stage: canvas is required.");
        }
        this.updateViewport();
    },

    canvas: null,
    renderer: null,
    paused: false,
    viewport: null,

    /**
     * 调用tick会触发舞台的更新和渲染。
     */
    tick: function(delta){
        if(!this.paused){
            this._render(this.renderer, delta);
        }
    },

    /**
     * 开启/关闭DOM事件功能。
     */
    enableDOMEvent: function(type, enable){
        var me = this,
            canvas = me.canvas,
            types = typeof type === 'string' ? [type] : type,
            handler = me._domListener || (me._domListener = function(e){me._onDOMEvent(e)});

        for(var i = 0; i < types.length; i++){
            var type = types[i];
            if(enable === false){
                canvas.removeEventListener(type, handler);   
            }else{
                canvas.addEventListener(type, handler, false);
            }
        }
    },

    /**
     * DOM事件处理函数。此方法会把事件调度到事件的坐标点所对应的可视对象。
     * @private
     */
    _onDOMEvent: function(e){
        var type = e.type, event = e, isTouch = type.indexOf('touch') == 0;

        //special for touch event
        if(isTouch){
            var touches = e.touches, changedTouches = e.changedTouches;
            event = (touches && touches.length) ? touches[0] : 
                    (changedTouches && changedTouches.length) ? changedTouches[0] : null;
            event.type = type;
        }

        //calculate stageX/stageY
        var x = event.pageX || event.clientX, y = event.pageY || event.clientY, 
            viewport = this.viewport;

        event.stageX = x = (x - viewport.left) / this.scaleX;
        event.stageY = y = (y - viewport.top) / this.scaleY;

        var obj = this.getViewAtPoint(x, y, true, false, true),
            canvas = this.canvas, target = this._eventTarget;

        //fire mouseout/touchout event for last event target
        var leave = type === 'mouseout' && !canvas.contains(e.relatedTarget); 
        if(target && (target != obj || leave)){
            var out = (type === 'touchmove') ? 'touchout' : 
                      (type === 'mousemove' || leave || !obj) ? 'mouseout' : null;
            if(out) target.fire(out);
            event.lastEventTarget = target;
            this._eventTarget = null;
        }
        
        //fire event for current view
        if(obj && obj.pointerEnabled && type !== 'mouseout'){
            event.eventTarget = this._eventTarget = obj;
            obj.fire(event);
        }
        
        //set cursor for current view
        if(!isTouch){
            var cursor = (obj && obj.pointerEnabled && obj.useHandCursor) ? 'pointer' : '';
            canvas.style.cursor = cursor;
        }

        //fire event for stage
        if(leave || type !== "mouseout") this.fire(event);
    },

    /**
     * 更新舞台在页面中的渲染区域。当舞台canvas的样式border、margin、padding等属性更改后，需要调用此方法更新舞台渲染区域。
     */
    updateViewport: function(){
        return this.viewport = Hilo.getElementRect(this.canvas);
    }

});

return Stage;

}, {
    requires: ['hilo/core/Hilo', 'hilo/core/Class', 'hilo/view/Container']
});