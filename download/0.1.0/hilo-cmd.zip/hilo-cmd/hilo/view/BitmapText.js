/**
 * Hilo 0.1.0 for CommonJS
 * Copyright 2014 hilojs.com
 * Licensed under the MIT License
 */

define(function(require, exports, module){

var Class = require('hilo/core/Class');
var Hilo = require('hilo/core/Hilo');
var Container = require('hilo/view/Container');

/**
 * @class BitmapText类提供使用位图文本的功能。当前仅支持单行文本。
 * @augments Container
 * @param {Object} properties 创建对象的属性参数。可包含此类所有可写属性。
 * @module hilo/view/BitmapText
 * @requires hilo/core/Class
 * @requires hilo/core/Hilo
 * @requires hilo/view/Container
 * @property {Object} glyphs 位图字体的字形集合。格式为：{letter:{image:img, rect:[0,0,100,100]}}。
 * @property {Number} letterSpacing 字距，即字符间的间隔。默认值为0。
 */
var BitmapText = Class.create(/** @lends BitmapText.prototype */{
    Extends: Container,
    constructor: function BitmapText(properties){
        properties = properties || {};
        this.id = this.id || properties.id || Hilo.getUid('BitmapText');
        BitmapText.superclass.constructor.call(this, properties);

        this.pointerChildren = false; //disable user events for single letters
    },

    glyphs: null,
    letterSpacing: 0,
    text: {
        get: function(){
            return this._text || '';
        },
        set: function(str){
            var me = this, str = str.toString(), len = str.length;
            if(me._text == str) return;
            me._text = str;
            me.removeAllChildren();

            var i, charStr, charGlyph, charObj, width = 0, height = 0;

            for(i = 0; i < len; i++){
                charStr = str.charAt(i);
                charGlyph = me.glyphs[charStr];
                if(charGlyph){
                    charObj = new Bitmap({
                        image: charGlyph.image,
                        rect: charGlyph.rect,
                        x: width
                    });
                    width += (width > 0 ? me.letterSpacing : 0) + charGlyph.rect[2];
                    heigth = Math.max(height, charGlyph.rect[3]);
                    me.addChild(charObj);
                }
            }

            me.width = width;
            me.height = height;
        }
    },

    /**
     * 返回能否使用当前指定的字体显示提供的字符串。
     * @param {String} str 要检测的字符串。
     * @returns {Boolean} 是否能使用指定字体。
     */
    hasGlyphs: function(str){
        var glyphs = this.glyphs;
        if(!glyphs) return false;

        var str = str.toString(), len = str.length, i;
        for(i = 0; i < len; i++){
            if(!glyphs[str.charAt(i)]) return false;
        }
        return true;
    }

});

return BitmapText;

});