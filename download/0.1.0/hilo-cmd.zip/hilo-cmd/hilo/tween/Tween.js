/**
 * Hilo 0.1.0 for CommonJS
 * Copyright 2014 hilojs.com
 * Licensed under the MIT License
 */

define(function(require, exports, module){

var Class = require('hilo/core/Class');

/**
 * @class Tween类提供缓动功能。
 * @param {Object} target 缓动对象。
 * @param {Object} newProps 对象缓动的目标属性集合。
 * @param {Object} params 缓动参数。可包含Tween类所有可写属性。
 * @module hilo/util/Tween
 * @requires hilo/core/Class
 * @property {Object} target 缓动目标。只读属性。
 * @property {Number} time 缓动总时长。单位毫秒。
 * @property {Number} delay 缓动延迟时间。单位毫秒。
 * @property {Boolean} paused 缓动是否暂停。默认为false。
 * @property {Boolean} loop 缓动是否循环。默认为false。
 * @property {Boolean} reverse 缓动是否反转播放。默认为false。
 * @property {Number} interval 缓动间隔。默认为0。
 * @property {Function} ease 缓动变化函数。默认为null。
 * @property {Tween} next 下一个缓动变化对象。默认为null。
 * @property {Function} onUpdate 缓动更新回调函数。默认为null。
 * @property {Function} onComplete 缓动结束回调函数。默认为null。
 */
var Tween = (function(){

return Class.create(/** @lends Tween.prototype */{
    constructor: function Tween(target, newProps, params){
        var me = this;
        me.target = target;

        me._oldProps = {};
        me._newProps = {};
        me._deltaProps = {};
        me._startTime = 0;
        me._lastTime = 0;
        me._pausedTime = 0;
        me._pausedStartTime = 0;
        me._reverseFlag = 1;
        me._frameTotal = 0;
        me._frameCount = 0;

        for(var p in newProps){       
            var oldVal = target[p], newVal = newProps[p];
            if(oldVal !== undefined){
                if(typeof oldVal == 'number' && typeof newVal == 'number'){
                    me._oldProps[p] = oldVal;
                    me._newProps[p] = newVal;
                    me._deltaProps[p] = newVal - oldVal;
                }
            }
        }

        for(var p in params){
            me[p] = params[p];
        }
    },

    target: null,
    time: 0,
    delay: 0,
    paused: false,
    loop: false,
    reverse: false,
    interval: 0,
    ease: null,
    next: null,

    onUpdate: null,
    onComplete: null,

    /**
     * 设置缓动对象的初始和目标属性。
     * @param oldProps 缓动对象的初始属性。
     * @param newProps 缓动对象的目标属性。
     */
    setProps: function(oldProps, newProps){
        for(var p in oldProps){
            this.target[p] = this._oldProps[p] = oldProps[p];
        }
        for(var p in newProps){
            this._newProps[p] = newProps[p];
            this._deltaProps[p] = newProps[p] - this.target[p];
        }
    },

    /**
     * 初始化Tween类。
     * @private
     */
    _init: function(){
        this._startTime = Date.now() + this.delay;
        this._pausedTime = 0;
        if(this.interval > 0) this._frameTotal = Math.round(this.time / this.interval);
        Tween.add(this);
    },

    /**
     * 启动缓动动画的播放。
     */
    start: function(){   
        this._init();
        this.paused = false;
    },

    /**
     * 停止缓动动画的播放。
     */
    stop: function(){
        Tween.remove(this);
    },

    /**
     * 暂停缓动动画的播放。
     */
    pause: function(){   
        this.paused = true;
        this._pausedStartTime = Date.now();
    },

    /**
     * 恢复缓动动画的播放。
     */
    resume: function(){   
        this.paused = false;
        this._pausedTime += Date.now() - this._pausedStartTime;
    },

    /**
     * Tween类的内部更新方法。
     * @private
     */
    _update: function(){
        if(this.paused) return;
        var now = Date.now();
        var elapsed = now - this._startTime - this._pausedTime;
        if(elapsed < 0) return;
        
        this._lastTime = now;
        
        var ratio = this._frameTotal > 0 ? (++this._frameCount / this._frameTotal) : (elapsed / this.time);
        if(ratio > 1) ratio = 1;
        var value = this.ease ? this.ease(ratio) : ratio;

        for(var p in this._oldProps){
            this.target[p] = this._oldProps[p] + this._deltaProps[p] * this._reverseFlag * value;
        }
        
        if(this.onUpdate) this.onUpdate(value);

        if(ratio >= 1){   
            if(this.reverse){
                var tmp = this._oldProps;
                this._oldProps = this._newProps;
                this._newProps = tmp;
                this._startTime = Date.now();
                this._frameCount = 0;
                this._reverseFlag *= -1;
            }else if(this.loop){
                for(var p in this._oldProps) this.target[p] = this._oldProps[p];
                this._startTime = Date.now();
                this._frameCount = 0;
            }else{
                Tween.remove(this);
                var next = this.next, nextTween;
                if(next){
                    if(next instanceof Tween){
                        nextTween = next;
                        next = null;
                    }else{
                        nextTween = next.shift();
                    }
                    if(nextTween){
                        nextTween.next = next;
                        nextTween.start();
                    }
                }
            }

            if(this.onComplete) this.onComplete(this);
            if(this.reverse && !this.loop) this.reverse = false;
        }
    },

    Statics: /** @lends Tween */ {
        /**
         * @private
         */
        _tweens: [],

        /**
         * 更新所有Tween实例。
         * @returns {Object} Tween。
         */
        tick: function(){
            var tweens = this._tweens, i = tweens.length;
            while(--i >= 0) tweens[i]._update();
            return this;
        },

        /**
         * 添加Tween实例。
         * @param {Tween} tween 要添加的Tween对象。
         * @returns {Object} Tween。
         */
        add: function(tween){
            if(this._tweens.indexOf(tween) == -1) this._tweens.push(tween);
            return this;
        },

        /**
         * 删除Tween实例。
         * @param {Tween} tween 要删除的Tween对象。
         * @returns {Object} Tween。
         */
        remove: function(tween){
            if(tween){
                var tweens = this._tweens;
                var index = tweens.indexOf(tween);
                if(index > -1) tweens.splice(index, 1);
            }
            return this;
        },

        /**
         * 删除所有Tween实例。
         * @returns {Object} Tween。
         */
        removeAll: function(){
            this._tweens.length = 0;
            return this;
        },

        /**
         * 创建一个缓动动画，让目标对象从当前属性变换到目标属性。
         * @param target 缓动目标对象。
         * @param toProps 缓动目标对象的目标属性。
         * @param params 缓动动画的参数。
         * @returns {Tween} 一个Tween实例对象。
         */
        to: function(target, toProps, params){
            var tween = new Tween(target, toProps, params);
            tween._init();
            return tween;
        },

        /**
         * 创建一个缓动动画，让目标对象从指定的起始属性变换到当前属性。
         * @param target 缓动目标对象。
         * @param toProps 缓动目标对象的起始属性。
         * @param params 缓动动画的参数。
         * @returns {Tween} 一个Tween实例对象。
         */
        from: function(target, fromProps, params){
            var tween = new Tween(target, fromProps, params);
            var tmp = tween._oldProps;
            tween._oldProps = tween._newProps;
            tween._newProps = tmp;
            tween._reverseFlag = -1;

            for(var p in tween._oldProps) target[p] = tween._oldProps[p];

            tween._init();
            return tween;
        }
    }

});

})();

return Tween;

});