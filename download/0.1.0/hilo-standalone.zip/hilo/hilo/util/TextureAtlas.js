/**
 * Hilo 0.1.0
 * Copyright 2014 hilojs.com
 * Licensed under the MIT License
 */

/**
 * @class TextureAtlas纹理集是将许多小的纹理图片整合到一起的一张大图。这个类可根据一个纹理集数据读取纹理小图、精灵动画等。
 * @param {Image} image 纹理集图片。
 * @param {Array} frameData 纹理集帧数据。每帧的数据格式为：[x, y, width, height]。
 * @param {Object} spriteData 纹理集精灵数据。
 * @module hilo/util/TextureAtlas
 * @require hilo/core/Class
 */
var TextureAtlas = (function(){

return Class.create(/** @lends TextureAtlas.prototype */{
    constructor: function TextureAtlas(image, frameData, spriteData){
        var result = parseAtlasData(image, frameData, spriteData);
        this._frames = result.frames;
        this._sprites = result.sprites;
    },

    _frames: null,
    _sprites: null,

    /**
     * 获取指定索引位置index的帧数据。
     * @param {Int} index 要获取帧的索引位置。
     * @returns {Object} 帧数据。
     */
    getFrame: function(index){
        var frames = this._frames;
        return frames && frames[index];
    },

    /**
     * 获取指定id的精灵数据。
     * @param {String} id 要获取精灵的id。
     * @returns {Object} 精灵数据。
     */
    getSprite: function(id){
        var sprites = this._sprites;
        return sprites && sprites[id];
    }
});

/**
 * 解析纹理集帧和精灵数据。
 * @private
 */
function parseAtlasData(image, frameData, spriteData){
    if(frameData === undefined){
        var data = image;
        image = data.image;
        frameData = data.frames;
        spriteData = data.sprites;
    }

    //frames
    if(frameData){
        var frames = [], frame, obj;

        for(var i = 0, len = frameData.length; i < len; i++){
            obj = frameData[i];
            frame = {
                image: image,
                rect: [obj[0], obj[1], obj[2], obj[3]],
                pivotX: obj[4] || 0,
                pivotY: obj[5] || 0
            };
            frames[i] = frame;
        }
    }

    //sprite frames
    if(spriteData){
        var sprites = {}, sprite, spriteFrames, spriteFrame;

        for(var s in spriteData){
            sprite = spriteData[s];
            if(isNumber(sprite)){
                spriteFrames = translateSpriteFrame(frames[sprite]);
            }else if(sprite instanceof Array){
                spriteFrames = [];
                for(var i = 0, len = sprite.length; i < len; i++){
                    var spriteObj = sprite[i], frameObj;
                    if(isNumber(spriteObj)){
                        spriteFrame = translateSpriteFrame(frames[spriteObj]);
                    }else{
                        frameObj = spriteObj.rect;
                        if(isNumber(frameObj)) frameObj = frames[spriteObj.rect];
                        spriteFrame = translateSpriteFrame(frameObj, spriteObj);
                    }
                    spriteFrames[i] = spriteFrame;
                }
            }
            sprites[s] = spriteFrames;
        }
    }

    return {frames:frames, sprites:sprites};
}

function isNumber(value){
    return typeof value === 'number';
}

function translateSpriteFrame(frameObj, spriteObj){
    var spriteFrame = {
        image: frameObj.image,
        rect: frameObj.rect,
        pivotX: frameObj.pivotX || 0,
        pivotY: frameObj.pivotY || 0
    };

    if(spriteObj){
        spriteFrame.name = spriteObj.name || null;
        spriteFrame.duration = spriteObj.duration || 0;
        spriteFrame.stop = !!spriteObj.stop;
        spriteFrame.next = spriteObj.next || null;
    }

    return spriteFrame;
}

})();